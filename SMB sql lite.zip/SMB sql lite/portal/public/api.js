const API_BASE = "/api";


// ============================================================
// LOGIN USER
// ============================================================

// 目前為免登入展示模式：固定使用 Wesley。
// 所有頁面都直接視為 Wesley 已登入。
const DEFAULT_LOGIN_USER = {
    id: 12,
    student_no: "wesley",
    name: "Wesley",
    department: "資訊工程系",
    phone: "",
    grade: "",
    email: "",
    role: "student"
};

function getLoginUser() {
    localStorage.setItem(
        "loginUser",
        JSON.stringify(DEFAULT_LOGIN_USER)
    );

    return { ...DEFAULT_LOGIN_USER };
}


// ============================================================
// REQUIRE LOGIN
// ============================================================

// 免登入模式：不再跳轉 login.html，直接使用預設 Wesley。
function requireLogin() {
    return getLoginUser();
}


// ============================================================
// LOGOUT
// ============================================================

// 目前不需要登入，因此登出後仍回到 index.html，並恢復 Wesley。
function logout() {
    localStorage.setItem(
        "loginUser",
        JSON.stringify(DEFAULT_LOGIN_USER)
    );

    window.location.replace("index.html");
}


// ============================================================
// API FETCH
// ============================================================

async function apiFetch(
    path,
    options = {}
) {

    const headers = {
        "Content-Type":
            "application/json",
        ...(options.headers || {})
    };

    const res =
        await fetch(
            API_BASE + path,
            {
                ...options,
                headers
            }
        );

    if (!res.ok) {

        const body =
            await res
                .json()
                .catch(() => ({}));

        const err =
            new Error(
                body.message ||
                body.error ||
                `HTTP ${res.status}`
            );

        err.status =
            res.status;

        err.body =
            body;

        throw err;
    }

    if (res.status === 204) {
        return null;
    }

    return res.json();

}


// ============================================================
// SCORE
// ============================================================

function scoreToLetter(score) {

    if (
        score === null ||
        score === undefined ||
        score === ""
    ) {
        return "—";
    }

    const s =
        Number(score);

    if (s >= 90) return "A+";
    if (s >= 85) return "A";
    if (s >= 80) return "A-";
    if (s >= 77) return "B+";
    if (s >= 73) return "B";
    if (s >= 70) return "B-";
    if (s >= 67) return "C+";
    if (s >= 63) return "C";
    if (s >= 60) return "C-";

    return "F";
}


function scoreToGpaPoint(score) {

    if (
        score === null ||
        score === undefined ||
        score === ""
    ) {
        return null;
    }

    const s =
        Number(score);

    if (s >= 90) return 4.3;
    if (s >= 85) return 4.0;
    if (s >= 80) return 3.7;
    if (s >= 77) return 3.3;
    if (s >= 73) return 3.0;
    if (s >= 70) return 2.7;
    if (s >= 67) return 2.3;
    if (s >= 63) return 2.0;
    if (s >= 60) return 1.7;

    return 0;
}


function formatScore(score) {

    return (
        score === null ||
        score === undefined ||
        score === ""
    )
        ? "—"
        : Number(score).toFixed(0);

}