const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const fs = require("fs");

const DB_PATH = process.env.SQLITE_DB || "/data/campus.db";

function ensureDir() {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
}

function openDatabase() {
  ensureDir();

  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        db.run("PRAGMA foreign_keys = ON");
        db.run("PRAGMA busy_timeout = 5000");
        db.run("PRAGMA journal_mode = WAL", (pragmaErr) => {
          if (pragmaErr) return reject(pragmaErr);
          resolve(db);
        });
      });
    });
  });
}

function all(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

function run(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve({
        affectedRows: this.changes || 0,
        insertId: this.lastID || 0
      });
    });
  });
}

async function query(sql, params = []) {
  const db = await openDatabase();

  try {
    const trimmed = sql.trim().toUpperCase();

    if (
      trimmed.startsWith("SELECT") ||
      trimmed.startsWith("PRAGMA") ||
      trimmed.startsWith("WITH")
    ) {
      return [await all(db, sql, params)];
    }

    return [await run(db, sql, params)];
  } finally {
    await close(db);
  }
}

function close(db) {
  return new Promise((resolve, reject) => {
    db.close((err) => {
      if (err) return reject(err);
      resolve();
    });
  });
}

async function getConnection() {
  const db = await openDatabase();

  return {
    query: async (sql, params = []) => {
      const trimmed = sql.trim().toUpperCase();

      if (
        trimmed.startsWith("SELECT") ||
        trimmed.startsWith("PRAGMA") ||
        trimmed.startsWith("WITH")
      ) {
        return [await all(db, sql, params)];
      }

      return [await run(db, sql, params)];
    },

    beginTransaction: () =>
      run(db, "BEGIN IMMEDIATE TRANSACTION"),

    commit: () =>
      run(db, "COMMIT"),

    rollback: () =>
      run(db, "ROLLBACK"),

    release: () =>
      close(db)
  };
}

module.exports = {
  query,
  getConnection,
  DB_PATH
};
