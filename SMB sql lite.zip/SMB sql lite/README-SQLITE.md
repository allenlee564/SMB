# SMB SQLite 版

這一版是以原本 `SMB` 專案為基礎修改，保留原本的目錄、前端、Nginx、CSV、SQL 備份、Git 資料與 Docker 結構；資料庫層改為 SQLite。

## SQLite 資料庫

資料庫位置：

```text
data/campus.db
```

目前資料已由原 SMB 的 `mysql-import/*.csv` 搬入：

- users: 11
- courses: 12
- enrollments: 23

## 啟動

```cmd
docker compose down
docker compose build --no-cache
docker compose up -d
```

## 檢查

```cmd
docker compose ps
curl.exe http://localhost/api/course/list
curl.exe http://localhost/api/student/1/courses
```

## 測試衝堂

學生 1 目前已有星期四 09:00-12:00 的「資料結構」。
「體育」是星期四 10:00-12:00，因此學生 1 嘗試加選體育時，API 應回傳：

```json
{
  "error": "schedule_conflict"
}
```

## MySQL 與 PostgreSQL

本 SQLite 版的 Docker Compose 不再啟動 MySQL/PostgreSQL；原本的 `mysql-import`、`campus_backup.sql`、文件與其他原始檔案仍保留，方便回復或查閱。
