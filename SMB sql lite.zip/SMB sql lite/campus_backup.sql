--
-- PostgreSQL database dump
--

\restrict 9h5iTdB9vJQns38dVayyMgtnINMUg4l2sd6g2lYmKHTmYIGjR2D9CLhD6mogzhb

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: campus
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    name text NOT NULL,
    teacher text,
    credits integer,
    course_code character varying(20),
    semester character varying(20),
    day_of_week integer,
    start_time time without time zone,
    end_time time without time zone,
    classroom character varying(50),
    capacity integer DEFAULT 50
);


ALTER TABLE public.courses OWNER TO campus;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: campus
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courses_id_seq OWNER TO campus;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: campus
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: campus
--

CREATE TABLE public.enrollments (
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    semester text,
    score numeric(5,2),
    status character varying(20) DEFAULT 'enrolled'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT enrollments_status_check CHECK (((status)::text = ANY ((ARRAY['enrolled'::character varying, 'dropped'::character varying])::text[])))
);


ALTER TABLE public.enrollments OWNER TO campus;

--
-- Name: incident_actions; Type: TABLE; Schema: public; Owner: campus
--

CREATE TABLE public.incident_actions (
    id integer NOT NULL,
    incident_id integer NOT NULL,
    action_type text,
    description text NOT NULL,
    performed_by integer,
    performed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incident_actions OWNER TO campus;

--
-- Name: incident_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: campus
--

CREATE SEQUENCE public.incident_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incident_actions_id_seq OWNER TO campus;

--
-- Name: incident_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: campus
--

ALTER SEQUENCE public.incident_actions_id_seq OWNED BY public.incident_actions.id;


--
-- Name: incidents; Type: TABLE; Schema: public; Owner: campus
--

CREATE TABLE public.incidents (
    id integer NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    source_ip inet,
    target_asset text,
    attack_type text,
    severity text,
    status text DEFAULT 'open'::text NOT NULL,
    description text,
    detected_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT incidents_severity_check CHECK ((severity = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text]))),
    CONSTRAINT incidents_status_check CHECK ((status = ANY (ARRAY['open'::text, 'investigating'::text, 'contained'::text, 'resolved'::text])))
);


ALTER TABLE public.incidents OWNER TO campus;

--
-- Name: incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: campus
--

CREATE SEQUENCE public.incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incidents_id_seq OWNER TO campus;

--
-- Name: incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: campus
--

ALTER SEQUENCE public.incidents_id_seq OWNED BY public.incidents.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: campus
--

CREATE TABLE public.users (
    id integer NOT NULL,
    student_no text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    department text,
    role text DEFAULT 'student'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    phone character varying(10),
    grade character varying(20),
    email character varying(255),
    CONSTRAINT users_phone_10_digits CHECK (((phone IS NULL) OR ((phone)::text ~ '^[0-9]{10}$'::text))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['student'::text, 'admin'::text])))
);


ALTER TABLE public.users OWNER TO campus;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: campus
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO campus;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: campus
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: incident_actions id; Type: DEFAULT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.incident_actions ALTER COLUMN id SET DEFAULT nextval('public.incident_actions_id_seq'::regclass);


--
-- Name: incidents id; Type: DEFAULT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.incidents ALTER COLUMN id SET DEFAULT nextval('public.incidents_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: campus
--

COPY public.courses (id, name, teacher, credits, course_code, semester, day_of_week, start_time, end_time, classroom, capacity) FROM stdin;
1	資料庫概論	王老師	3	CS101	2025-2	1	09:00:00	12:00:00	A301	50
2	網路安全導論	李老師	3	CS202	2025-2	3	13:00:00	16:00:00	B201	50
3	程式設計	林老師	3	CS103	2025-2	2	09:00:00	12:00:00	A201	50
4	資料結構	張老師	3	CS204	2025-2	4	09:00:00	12:00:00	A302	50
5	作業系統	陳老師	3	CS205	2025-2	1	13:00:00	16:00:00	B101	50
6	計算機網路	黃老師	3	CS206	2025-2	3	09:00:00	12:00:00	B202	50
7	網頁程式設計	吳老師	3	CS207	2025-2	2	13:00:00	16:00:00	C101	50
8	軟體工程	劉老師	3	CS208	2025-2	4	13:00:00	16:00:00	C201	50
9	人工智慧導論	蔡老師	3	CS209	2025-2	5	09:00:00	12:00:00	A401	50
10	資訊管理	楊老師	3	CS210	2025-2	5	13:00:00	16:00:00	B301	50
11	大學英文	林老師	2	GE101	2025-2	2	10:00:00	12:00:00	D101	60
12	體育	王老師	2	GE102	2025-2	4	10:00:00	12:00:00	體育館	60
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: campus
--

COPY public.enrollments (student_id, course_id, semester, score, status, created_at) FROM stdin;
2	1	2025-2	\N	enrolled	2026-08-11 05:55:54.171802+00
3	2	2025-2	92.00	enrolled	2026-08-11 05:55:54.171802+00
4	1	2025-2	68.00	enrolled	2026-08-11 05:55:54.171802+00
4	2	2025-2	81.00	enrolled	2026-08-11 05:55:54.171802+00
5	2	2025-2	\N	enrolled	2026-08-11 05:55:54.171802+00
6	1	2025-2	95.00	enrolled	2026-08-11 05:55:54.171802+00
7	1	2025-2	55.00	enrolled	2026-08-11 05:55:54.171802+00
7	2	2025-2	60.00	enrolled	2026-08-11 05:55:54.171802+00
8	2	2025-2	77.00	enrolled	2026-08-11 05:55:54.171802+00
9	1	2025-2	\N	enrolled	2026-08-11 05:55:54.171802+00
10	1	2025-2	89.00	enrolled	2026-08-11 05:55:54.171802+00
10	2	2025-2	91.00	enrolled	2026-08-11 05:55:54.171802+00
1	3	2025-2	\N	enrolled	2026-08-11 06:46:01.709693+00
1	4	2025-2	\N	enrolled	2026-08-11 06:46:24.278062+00
1	5	2025-2	\N	enrolled	2026-08-11 07:13:42.357149+00
1	6	2025-2	\N	enrolled	2026-08-11 07:13:47.484442+00
1	7	2025-2	\N	enrolled	2026-08-11 07:19:12.718732+00
1	8	2025-2	\N	enrolled	2026-08-11 07:23:30.338863+00
1	9	2025-2	\N	enrolled	2026-08-11 07:34:46.557166+00
1	10	2025-2	\N	enrolled	2026-08-11 08:34:52.671595+00
1	11	2025-2	\N	enrolled	2026-08-11 08:35:05.47236+00
1	1	2025-2	88.00	dropped	2026-08-11 05:55:54.171802+00
1	2	2025-2	75.00	dropped	2026-08-11 05:55:54.171802+00
\.


--
-- Data for Name: incident_actions; Type: TABLE DATA; Schema: public; Owner: campus
--

COPY public.incident_actions (id, incident_id, action_type, description, performed_by, performed_at) FROM stdin;
1	1	修補漏洞	將 SQL 查詢改為 parameterized query，並補上輸入驗證。	11	2026-08-09 06:55:54.121246+00
2	1	封鎖IP	於 nginx 層封鎖來源 IP 203.0.113.45。	11	2026-08-09 06:05:54.121246+00
3	2	調整防火牆規則	對登入端點加上暫時性 rate limit，持續觀察中。	11	2026-08-11 03:10:54.123168+00
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: campus
--

COPY public.incidents (id, detected_at, source_ip, target_asset, attack_type, severity, status, description, detected_by, created_at) FROM stdin;
1	2026-08-09 05:55:54.121246+00	203.0.113.45	student-api	SQL Injection	high	resolved	在 /api/student/:id 參數偵測到 SQLi 嘗試，Wazuh 告警觸發。	11	2026-08-11 05:55:54.121246+00
2	2026-08-11 02:55:54.123168+00	198.51.100.23	nginx	Brute Force	medium	investigating	短時間內對 /api/student/login 大量嘗試不同帳密。	11	2026-08-11 05:55:54.123168+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: campus
--

COPY public.users (id, student_no, password_hash, name, department, role, created_at, phone, grade, email) FROM stdin;
2	B11123002	$2a$06$JHt4leZg3hCub8wnzVsaQeN9VFu1GGIvmMB/uey9Q1eSXiYbLQtlu	林同學	資訊工程系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
3	B11123003	$2a$06$OeblhMcCvw3niGlV5sOYPOiChpkaEl.ruNbaOqcYpV3ChKtK9r76i	黃同學	電機工程系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
4	B11123004	$2a$06$lXJtBYkmwpDOJ2IHCWf/OOHwtc70bPqpoRQyhSci2E.DO91FIuVEa	張同學	企業管理系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
5	B11123005	$2a$06$1xpezZcLeqQFONnTueEgkea0U9UCXiBviHvfR5PUG0JobJAuWYRaG	李同學	應用外語系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
6	B11123006	$2a$06$PrFdcC/Eciw.H2DYQpW5p.SEMQW6xrFDWhyaq6GZi1Q9kpar4NJx.	王同學	資訊管理系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
7	B11123007	$2a$06$KRrCK.Hg1ItYTAGjQUWts.nr8FF.L.A7wo0Zjd2uxXBZFu1AfHYGy	吳同學	機械工程系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
8	B11123008	$2a$06$N9XmPP0Lan1DNetHEbMKdOWEBA3CkrYICQBuC43fug5u5P/IT10DC	劉同學	財務金融系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
9	B11123009	$2a$06$2.eiovue11EfZH1XmlBsnOZ6m8hukXWIf4CoJwJUcfc13cBsAuEoy	蔡同學	大眾傳播系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
10	B11123010	$2a$06$LifH7xLlstEgV5B94IaL6eGg2z2T31EQ1xnYrAIvv9GIRHqj/zhwy	楊同學	運動科學系	student	2026-08-11 05:55:54.066654+00	\N	\N	\N
11	A00000001	$2a$06$qXozzzhiGa2nOZjs5xI0Ouq.FwyBvUEhP55ZzjLRhb1OT94T1BLpq	系統管理員	\N	admin	2026-08-11 05:55:54.066654+00	\N	\N	\N
1	B11123001	$2a$06$befycFA0Gv3rsb.C0ISLHuI4CaKk5.IZCW3lby1B1lWwO6VhCxMxO	陳同學	資訊工程系	student	2026-08-11 05:55:54.066654+00	1233456789	\N	\N
\.


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: campus
--

SELECT pg_catalog.setval('public.courses_id_seq', 12, true);


--
-- Name: incident_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: campus
--

SELECT pg_catalog.setval('public.incident_actions_id_seq', 3, true);


--
-- Name: incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: campus
--

SELECT pg_catalog.setval('public.incidents_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: campus
--

SELECT pg_catalog.setval('public.users_id_seq', 11, true);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (student_id, course_id);


--
-- Name: incident_actions incident_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.incident_actions
    ADD CONSTRAINT incident_actions_pkey PRIMARY KEY (id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_student_no_key; Type: CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_student_no_key UNIQUE (student_no);


--
-- Name: idx_incident_actions_incident_id; Type: INDEX; Schema: public; Owner: campus
--

CREATE INDEX idx_incident_actions_incident_id ON public.incident_actions USING btree (incident_id);


--
-- Name: idx_incidents_detected_at; Type: INDEX; Schema: public; Owner: campus
--

CREATE INDEX idx_incidents_detected_at ON public.incidents USING btree (detected_at);


--
-- Name: idx_incidents_status; Type: INDEX; Schema: public; Owner: campus
--

CREATE INDEX idx_incidents_status ON public.incidents USING btree (status);


--
-- Name: enrollments enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: enrollments enrollments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id);


--
-- Name: incident_actions incident_actions_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.incident_actions
    ADD CONSTRAINT incident_actions_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: incident_actions incident_actions_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.incident_actions
    ADD CONSTRAINT incident_actions_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: incidents incidents_detected_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: campus
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_detected_by_fkey FOREIGN KEY (detected_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 9h5iTdB9vJQns38dVayyMgtnINMUg4l2sd6g2lYmKHTmYIGjR2D9CLhD6mogzhb

