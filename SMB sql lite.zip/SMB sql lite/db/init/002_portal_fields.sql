-- ============================================
-- Campus Portal
-- Migration 002
-- ============================================

-- USERS
ALTER TABLE users
ADD COLUMN IF NOT EXISTS phone VARCHAR(10);

ALTER TABLE users
ADD COLUMN IF NOT EXISTS grade VARCHAR(20);

ALTER TABLE users
ADD COLUMN IF NOT EXISTS email VARCHAR(255);

ALTER TABLE users
DROP CONSTRAINT IF EXISTS users_phone_10_digits;

ALTER TABLE users
ADD CONSTRAINT users_phone_10_digits
CHECK (
    phone IS NULL
    OR phone ~ '^[0-9]{10}$'
);


-- COURSES
ALTER TABLE courses
ADD COLUMN IF NOT EXISTS course_code VARCHAR(20);

ALTER TABLE courses
ADD COLUMN IF NOT EXISTS semester VARCHAR(20);

ALTER TABLE courses
ADD COLUMN IF NOT EXISTS day_of_week INTEGER;

ALTER TABLE courses
ADD COLUMN IF NOT EXISTS start_time TIME;

ALTER TABLE courses
ADD COLUMN IF NOT EXISTS end_time TIME;

ALTER TABLE courses
ADD COLUMN IF NOT EXISTS classroom VARCHAR(50);

ALTER TABLE courses
ADD COLUMN IF NOT EXISTS capacity INTEGER DEFAULT 50;


-- ENROLLMENTS
ALTER TABLE enrollments
ADD COLUMN IF NOT EXISTS status VARCHAR(20)
DEFAULT 'enrolled';

ALTER TABLE enrollments
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE
DEFAULT now();

ALTER TABLE enrollments
DROP CONSTRAINT IF EXISTS enrollments_status_check;

ALTER TABLE enrollments
ADD CONSTRAINT enrollments_status_check
CHECK (
    status IN ('enrolled', 'dropped')
);