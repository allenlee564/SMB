# CLAUDE.md — Metis

專案層規則，優先於全域 `~/.claude/CLAUDE.md`。人類協作規範見 `CONTRIBUTING.md`。

## 語言

- **Issue 的標題與內文一律使用中文。**
- **Commit 訊息使用中文** —— 一行祈使句，說明「為什麼」而不是「改了什麼」。
  - 好：`使用本地大模型避免資料傳輸到第三方`
  - 壞：`update`、`fix bug`、`修改檔案`
- 這兩條覆寫全域「commit 訊息用英文」的預設。本專案文件與筆記皆為中文。
- 程式碼、識別字、註解仍維持英文。

## Git

- **禁止直接推送 `main`。** 一律開分支走 PR。
- 分支命名：`<分類>/<簡述>`
  - `feat/web-terminal`、`fix/log-parser`、`docs/threat-model`
  - 分類只有三種：`feat` / `fix` / `docs`。想不到用哪個就用 `feat`。
- **處理 GitHub issue 時，用 `gh issue develop` 建立分支**，不要手動 `git branch` —— 前者會把分支與 issue 連結起來：

  ```bash
  gh issue develop <issue編號> --checkout --name "<分類>/<簡述>"
  ```

- 合併用 **Squash and merge**，讓 `main` 的歷史一個 PR 一個 commit。
