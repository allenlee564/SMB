# 藍隊 target-box 現況總整理

版本：v1.0（2026-08-12）
範圍：`~/test` 底下的實作（`target-box`、`target-internal`、`blue-terminal`、`scoring-engine`）
對照依據：`se-218/Metis` repo 的 issues (#1, #2, #3, #6, #11, #12) 與 PR#10「決策記錄001 - 藍隊環境規格與漏洞修補回覆」（已merge，內容與我們的規劃逐字吻合）

---

## 一、跟官方決策記錄（決策記錄001）的對齊狀況

決策記錄001 已明確承諾的事項：

| 項目 | 官方決策 | 我們現在的實作 | 狀態 |
|---|---|---|---|
| 幾台主機 | 2台（對外target-box + 對內target-internal） | 已建置，雙網卡+網路隔離已測試 | ✅ 一致 |
| 資料庫 | **SQLite**（為省VM記憶體，降至250MB內） | **MySQL**（完整mysql-server） | ❌ **不一致，待修** |
| 漏洞數量 | 5正式+1隱藏，120分 | 同樣6項，內容逐一對應 | ✅ 一致 |
| 工具清單 | vim/nano/less/grep/find/iptables/net-tools/iproute2/tcpdump/supervisor/sqlite-client/openssh-client | 同款清單，但裝的是mysql-client不是sqlite-client | ⚠️ 待SQLite遷移後一併修正 |
| flag/計分機制 | Python自動化驗證，PASS/FAIL，六項各自檢查函式 | `checker.py` 已實作並測試過（0分↔120分皆驗證） | ✅ 一致 |
| 存活檢查 | `GET /`、`/api/course/health`、`/api/student/health` 三個都過才算活 | `watchdog.py` 已實作並測試（正常/服務被關掉都驗證過） | ✅ 一致 |

---

## 二、跟 GitHub Issues 的對照

| Issue | 內容 | 我們的狀況 |
|---|---|---|
| **#11**（籃隊docker包裝，3要求） | (1)能用docker compose (2)全部服務在一個container (3)WebServer不能用root跑 | (1)✅ (2)✅ (3)✅ **已修復**——`course-api`/`student-api`/`portal`改由`www-data`執行，webshell RCE落地身份實測確認為`www-data`，漏洞3/5的提權路徑恢復教學意義 |
| **#1**（三個會弄壞漏洞的問題） | .env/uploads的chown問題、SUID/sudoers在root環境下失效、shadow要有可破解密碼 | `.env`不會被程式實際讀取（純粹是埋的假檔案），不會有owner衝突問題；沒有uploads功能，不適用；shadow裡`user1:user123`本來就是可破解的弱密碼，已符合；**SUID/sudoers提權失效的問題，本質上就是#11第3點同一件事——WebServer若是root跑，紅隊拿到webshell直接就是root，漏洞3(sudoers提權)形同虛設** |
| **#2**（計分判定條件不足，已CLOSED） | 原本針對10漏洞版本，點名PDF匯出RCE跟JWT弱金鑰難以判定；建議存活檢查連續失敗3次才算失效 | 這兩個難判定的漏洞已經不在我們的6項清單裡，不適用；`checker.py`本來就是用具體條件（權限值/DB筆數/iptables規則）判定，不是模糊描述；**watchdog.py目前是單次失敗就判定失效，尚未採納「連續3次」的建議，待補強** |
| **#3**（活動設計，已有共識但未實作） | 紅隊補完洞後沒東西打（解法：webshell不能刪只能封鎖IP，已符合）；紅藍計分應連動（提案：紅隊攻進去該題藍隊扣50%）；難度加權（easy×0.8/normal×1.0/hard×1.3） | webshell規則我們已符合（規則本來就寫不能刪除只能封鎖）；**紅藍計分連動、難度加權，`checker.py`目前都還沒實作，是純粹的獨立判分** |
| **#6**（藍隊push東西開PR） | 要求把藍隊的東西推到`Blue/`資料夾並開PR | **`Blue/`資料夾目前是空的，我們的東西還在本機`~/test`，尚未推送**（且用戶已明確交代這階段不commit不push） |
| **#12**（紫隊中央入口） | 需要公網TLS（Cloudflare Tunnel等） | 資訊性，不影響我們現在的工作範圍 |

---

## 三、待辦優先順序

### P0（跟已公開的官方承諾不一致，應優先處理）
- [ ] MySQL → SQLite 遷移（target-box整個資料層要換）——**使用者決定暫緩，先不做**
- [x] `course-api`/`student-api`/`portal` 改用非root（`www-data`）執行，只有藍隊的terminal入口維持root——**已完成並實測驗證**

### P1（issue提到、值得順手修的品質問題）
- [ ] `watchdog.py` 加上「連續失敗3次才判定失效」

### P2（功能尚未開始，之後排入）
- [ ] 來賓端計分板（讓guest自己看得到分數即時更新，不影響checker判斷邏輯留在host端的原則）
- [ ] 紅藍計分連動機制（紅隊攻進某漏洞→該題藍隊扣50%分）
- [ ] 難度加權係數（0.8/1.0/1.3）

### P3（協作流程，何時做要看使用者決定）
- [ ] 依issue #6要求，把`target-box`/`target-internal`/`blue-terminal`/`scoring-engine`推到`se-218/Metis`的`Blue/`資料夾並開PR

---

## 四、今天已完成且實測驗證過的（完整清單）

見對話紀錄，摘要：target-box（校園portal+6漏洞+提示系統）、target-internal（橫向移動目標）、blue-terminal（ttyd外部終端橋接）、scoring-engine（checker.py+watchdog.py）、docker-compose.yml（LAB_ID/WEB_PORT/TERMINAL_PORT/DIFFICULTY全參數化，支援多來賓並行）。student-api額外修補一個IDOR漏洞（加JWT）。全程未commit未push。
