#!/usr/bin/env python3
"""
服務存活檢查——藍隊不能用「關掉服務」來防守，這支從外部（跟紅隊視角一樣）
定期戳幾個關鍵端點，全部正常才算「服務還活著」。

用法：
  python3 watchdog.py http://localhost:18080
  python3 watchdog.py http://localhost:18080 --loop 15
"""

import sys
import json
import time
import urllib.request
import urllib.error


def check_endpoint(base_url, path, expect_json_ok=False):
    url = base_url.rstrip("/") + path
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            status = resp.status
            body = resp.read().decode("utf-8", errors="replace")
    except urllib.error.URLError as e:
        return False, f"連線失敗: {e}"
    except Exception as e:
        return False, f"錯誤: {e}"

    if status != 200:
        return False, f"HTTP {status}"

    if expect_json_ok:
        try:
            data = json.loads(body)
            if data.get("status") != "ok":
                return False, f"回應內容非預期: {body[:100]}"
        except json.JSONDecodeError:
            return False, f"回應不是合法JSON: {body[:100]}"

    return True, f"HTTP {status}"


ENDPOINTS = [
    ("portal_home", "/", False),
    ("course_api_health", "/api/course/health", True),
    ("student_api_health", "/api/student/health", True),
]


def run_once(base_url):
    results = []
    all_alive = True

    for name, path, expect_json in ENDPOINTS:
        ok, detail = check_endpoint(base_url, path, expect_json)
        if not ok:
            all_alive = False
        results.append({"endpoint": name, "path": path, "alive": ok, "detail": detail})

    return {
        "target": base_url,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "alive": all_alive,
        "endpoints": results,
    }


def main():
    if len(sys.argv) < 2:
        print("用法: python3 watchdog.py <base_url> [--loop 秒數]")
        sys.exit(1)

    base_url = sys.argv[1]
    loop_seconds = None
    if "--loop" in sys.argv:
        loop_seconds = int(sys.argv[sys.argv.index("--loop") + 1])

    while True:
        report = run_once(base_url)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        status_text = "存活" if report["alive"] else "!! 失效 !!"
        print(f"\n服務狀態: {status_text}")

        if loop_seconds is None:
            break
        time.sleep(loop_seconds)


if __name__ == "__main__":
    main()
