# 測試方式與計分說明

## 一、怎麼測試環境

### 1. 啟動一份來賓環境

```bash
cd ~/test
LAB_ID=01 WEB_PORT=18080 TERMINAL_PORT=17681 DIFFICULTY=easy docker compose -p lab01 up -d --build
```

- `LAB_ID`：這場的代號，同時開多場給不同`LAB_ID`即可互不干擾
- `WEB_PORT`：校園portal網站的對外port
- `TERMINAL_PORT`：終端機（ttyd）的對外port，開 `http://localhost:<TERMINAL_PORT>/cli/`
- `DIFFICULTY`：目前沒有任何指令消費這個變數（原本給`hint`指令用，已移除），保留參數是為了不動啟動介面，之後有難度分級需求可以重新接上

### 2. 換人重置（清成全新狀態）

```bash
docker compose -p lab01 down
LAB_ID=01 WEB_PORT=18080 TERMINAL_PORT=17681 DIFFICULTY=easy docker compose -p lab01 up -d
```

### 3. 進去操作

瀏覽器開 `http://localhost:17681/cli/`，會透過ttyd拿到`target-box`的root shell。

查看目前分數與進度：
```bash
score
```

依序修補七項（詳細指令見下方「計分依據」表格最右欄）。

### 4. 驗證分數

`checker`是`docker-compose.yml`裡的一個服務，環境一起來就會**自動**每15秒判分一次、推進`target-box`給`score`指令讀，不用手動開：

```bash
docker logs -f checker-01              # 看裁判端即時判分log
```

需要跑一次性、非固定週期的檢查時（例如剛好想立刻看某一項改完的結果，不想等下個15秒週期），才需要手動在host上跑：

```bash
cd ~/test/scoring-engine
python3 checker.py target-box-01              # 檢查一次
```

### 5. 確認服務沒被違規關掉

```bash
python3 watchdog.py http://localhost:18080              # 檢查一次
python3 watchdog.py http://localhost:18080 --loop 15     # 每15秒持續檢查
```

---

## 二、計分怎麼算

**滿分140分（5項正式漏洞各20分 + 2項隱藏加分題各20分）**，每項獨立判定，**PASS拿滿分、FAIL拿0分，沒有部分給分**。判定邏輯全部是具體可執行的條件，不是人工主觀評分，而且都是「查實際狀態/實際權限」，不是只看單一檔案存不存在。

| # | 項目 | 分數 | 判定條件 | 修補指令 |
|---|---|---|---|---|
| 1 | `.env`外洩 | 20 | `/opt/portal/.env` 權限 ≤600 | `chmod 600 /opt/portal/.env` |
| 2 | shadow可讀 | 20 | `/etc/shadow` 權限 ≤640 且 group為 `shadow`/`root` | `chmod 600 /etc/shadow` |
| 3 | sudoers提權 | 20 | `sudo -l -U user1` 不再出現 `NOPASSWD` 執行 vim 的權限（刪檔案、改內容拿掉NOPASSWD都算過） | `rm /etc/sudoers.d/user1_vuln` |
| 4 | DB橫向移動憑證 | 20 | `internal_hosts`表筆數=0（用獨立的`grader`唯讀帳號查，不受學員是否更動`root`密碼影響） | `mysql --default-character-set=utf8mb4 -uroot -pcampus_root campus_db -e "DELETE FROM internal_hosts;"` |
| 5 | backup腳本777 | 20 | owner=root:root 且 權限 ≤700 | `chown root:root /opt/scripts/system_backup.sh && chmod 700 /opt/scripts/system_backup.sh` |
| 6（隱藏bonus） | webshell鑑識+封鎖 | 20 | log裡出現過的**每一個**來源IP都被iptables擋掉（精確IP比對，且支援CIDR網段封鎖） | `grep backdoor /var/log/nginx/access_json.log` 找出所有IP，逐一 `iptables -A INPUT -s <IP> -j DROP` |
| 7（隱藏bonus） | 容器逃逸（docker socket曝露） | 20 | `/var/run/dind/docker.sock` 已不存在，或存在但實際嘗試連線會失敗 | `rm -f /var/run/dind/docker.sock`（⚠️`chmod`對root無效，root本來就無視檔案權限位元，只有真正移除socket才擋得住） |

**判定引擎**：`checker.py`，一支Python腳本，用 `docker exec` 從**host端**（容器外部）檢查上述條件，可用 `--loop <秒數>` 設定檢查間隔（原始劇本建議30秒，秒數可自行調整；同時跑多個`LAB_ID`時間隔不宜設太短，避免host負擔過大）。

**輸出**：每次檢查會印出JSON並寫入 `leaderboard_target-box-01.json`（檔名依`target容器名稱`變化），包含每項的 `status`(pass/fail/pending)、`score`、`detail`（具體檢查到的數值，方便debug）；同時會把結果推進容器內的`/opt/score/status.json`，來賓在`target-box`裡下`score`指令就能看到，判定邏輯本身仍不進容器。

---

## 三、隱藏關卡7：容器逃逸沙盒

因為正式上線後多場來賓會**共用同一台VM**，`target-box`沒有掛host真正的`/var/run/docker.sock`，而是掛一個獨立的`target-dind`容器（每個`LAB_ID`各一份、彼此隔離）的socket，路徑在`/var/run/dind/docker.sock`。紅隊逃逸出去看到的「host」其實是這個一次性的沙盒，不會波及其他來賓或VM本身。

- socket權限是 `root:2375`（DinD內部的docker群組GID），**紅隊得先靠漏洞3或5拿到容器內root才摸得到**，`user1`直接連線會被拒絕
- 逃逸方式：`docker -H unix:///var/run/dind/docker.sock run --rm -v /:/hostfs alpine cat /hostfs/root/flag_escape.txt`
- flag：`FLAG{container_escape_via_exposed_docker_socket}`
