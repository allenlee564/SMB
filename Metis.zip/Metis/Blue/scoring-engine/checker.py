#!/usr/bin/env python3
"""
自動化驗證/計分引擎——對 target-box 的六個漏洞逐一檢查修補狀態。

跑在 host 上（透過 `docker exec` 檢查，不進容器裡跑），來賓拿不到這支程式，
分數不可能被來賓自己竄改。

用法：
  python3 checker.py target-box-01            # 檢查一次，印出並存檔
  python3 checker.py target-box-01 --loop 30   # 每30秒檢查一次
"""

import subprocess
import json
import time
import sys
import re
import ipaddress


def docker_exec(target, cmd):
    result = subprocess.run(
        ["docker", "exec", target, "bash", "-c", cmd],
        capture_output=True, text=True, timeout=10,
    )
    return result.stdout.strip(), result.returncode


def push_score_to_container(target, report):
    """把評分結果推進容器內的唯讀狀態檔，給來賓的 `score` 指令讀取。
    判定邏輯本身（這支程式）不進容器，來賓只能看結果，改不了判定條件。"""
    payload = json.dumps(report, ensure_ascii=False)
    try:
        subprocess.run(
            ["docker", "exec", "-i", target, "bash", "-c",
             "mkdir -p /opt/score && cat > /opt/score/status.json && chmod 644 /opt/score/status.json"],
            input=payload, capture_output=True, text=True, timeout=10,
        )
    except Exception as e:
        print(f"[警告] 推送分數進容器失敗：{e}")


def check_env_exposure(target):
    out, code = docker_exec(target, "stat -c '%a %U' /opt/portal/.env 2>/dev/null")
    if code != 0 or not out:
        return False, "找不到 /opt/portal/.env"
    perm, owner = out.split()
    ok = int(perm, 8) <= 0o600
    return ok, f"權限={perm} owner={owner}（要求 <=600）"


def check_shadow_permission(target):
    out, code = docker_exec(target, "stat -c '%a %G' /etc/shadow 2>/dev/null")
    if code != 0 or not out:
        return False, "找不到 /etc/shadow"
    perm, group = out.split()
    ok = int(perm, 8) <= 0o640 and group in ("shadow", "root")
    return ok, f"權限={perm} group={group}（要求 <=640 且 group 為 shadow/root）"


def check_sudoers_vuln(target):
    # 檢查 user1 實際的 sudo 權限，而不是特定檔案存不存在——
    # 不管學員是刪檔案、改內容拿掉 NOPASSWD、還是搬到別的檔名，
    # 只要 user1 已經沒有免密碼跑 vim 的權限就算過
    out, _ = docker_exec(target, "sudo -l -U user1 2>/dev/null")
    vulnerable = bool(re.search(r"NOPASSWD.*vim", out, re.IGNORECASE))
    ok = not vulnerable
    return ok, ("user1 sudo -l 仍允許: " + out) if vulnerable else "user1 已無 NOPASSWD 執行 vim 的權限"


def check_db_creds_cleaned(target):
    # 用獨立的唯讀 grader 帳號連線判定，不依賴漏洞1外洩的 root 密碼——
    # 學員把外洩密碼改掉（正確的資安反應）不會連帶讓這題的判定失效
    out, code = docker_exec(
        target,
        "mysql --default-character-set=utf8mb4 -ugrader -pgrader_ro_9f3a2b -N "
        "-e 'SELECT COUNT(*) FROM campus_db.internal_hosts;' 2>/dev/null",
    )
    if code != 0 or not out.strip().isdigit():
        return False, "查詢 internal_hosts 失敗"
    count = int(out.strip())
    ok = count == 0
    return ok, f"internal_hosts 剩餘 {count} 筆（要求 0）"


def check_backup_script(target):
    out, code = docker_exec(
        target, "stat -c '%a %U:%G' /opt/scripts/system_backup.sh 2>/dev/null"
    )
    if code != 0 or not out:
        return False, "找不到 backup script"
    perm, owner = out.split()
    ok = int(perm, 8) <= 0o700 and owner == "root:root"
    return ok, f"權限={perm} owner={owner}（要求 <=700 且 root:root）"


def check_webshell_ip_blocked(target):
    ips_out, _ = docker_exec(
        target,
        r"grep 'backdoor.php' /var/log/nginx/access_json.log 2>/dev/null | "
        r"grep -oE '\"remote_addr\":\"[0-9.]+\"' | grep -oE '[0-9.]+' | sort -u",
    )
    ips = [ip for ip in ips_out.splitlines() if ip]
    if not ips:
        return None, "尚未偵測到任何 webshell 存取紀錄"

    # 用 -S（規則格式）取代 -L -n（表格格式），並用 ipaddress 模組做精確的
    # 網段比對，取代原本的字串包含比對——避免「172.20.0.10」被誤判成
    # 包含在「172.20.0.100」裡，同時也支援學員直接封鎖整個 CIDR 網段
    rules_out, _ = docker_exec(target, "iptables -S INPUT 2>/dev/null")
    blocked_nets = []
    for m in re.finditer(r"-s (\d+\.\d+\.\d+\.\d+(?:/\d+)?)", rules_out):
        try:
            blocked_nets.append(ipaddress.ip_network(m.group(1), strict=False))
        except ValueError:
            continue

    unblocked = [
        ip for ip in ips
        if not any(ipaddress.ip_address(ip) in net for net in blocked_nets)
    ]
    ok = len(unblocked) == 0
    return ok, f"曾存取webshell的IP={ips}；未封鎖={unblocked or '無'}"


def check_docker_socket_exposed(target):
    # 隱藏關卡7：/var/run/dind/docker.sock 是掛進來的沙盒daemon（見target-dind），
    # 不是host真正的docker.sock。判定方式是實際嘗試用它跟daemon對話，而不是只看
    # 檔案存不存在——藍隊不管是移除socket還是收回權限，只要用不了就算過
    out, _ = docker_exec(
        target,
        "test -S /var/run/dind/docker.sock || { echo NO_SOCKET; exit 0; }; "
        "timeout 3 docker -H unix:///var/run/dind/docker.sock version >/dev/null 2>&1 "
        "&& echo USABLE || echo BLOCKED",
    )
    result = out.strip()
    ok = result in ("NO_SOCKET", "BLOCKED")
    detail_map = {
        "NO_SOCKET": "docker socket 已移除，容器逃逸路徑已阻絕",
        "BLOCKED": "docker socket 仍存在但已無法使用（權限已收回）",
        "USABLE": "docker socket 仍可用，容器逃逸路徑尚未阻絕",
    }
    return ok, detail_map.get(result, f"未預期的檢查結果: {result!r}")


CHECKS = [
    ("vuln1_env_exposure", ".env 外洩 MySQL root 密碼", check_env_exposure, 20),
    ("vuln2_shadow_perm", "/etc/shadow 權限過寬", check_shadow_permission, 20),
    ("vuln3_sudoers_vim", "sudoers 允許 sudo vim 提權", check_sudoers_vuln, 20),
    ("vuln4_db_creds", "DB 存明文內網SSH憑證", check_db_creds_cleaned, 20),
    ("vuln5_backup_script", "backup 腳本權限777", check_backup_script, 20),
    ("vuln6_webshell_bonus", "隱藏webshell鑑識+封鎖(bonus)", check_webshell_ip_blocked, 20),
    ("vuln7_docker_escape", "容器逃逸(docker socket曝露)(bonus)", check_docker_socket_exposed, 20),
]


def run_once(target):
    results = []
    total_score = 0
    max_score = 0

    for key, label, fn, points in CHECKS:
        try:
            ok, detail = fn(target)
        except Exception as e:
            ok, detail = False, f"檢查發生錯誤：{e}"

        if ok is None:
            status, score = "pending", 0
        elif ok:
            status, score = "pass", points
        else:
            status, score = "fail", 0

        total_score += score
        max_score += points

        results.append({
            "id": key,
            "label": label,
            "status": status,
            "score": score,
            "max_score": points,
            "detail": detail,
        })

    return {
        "target": target,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "total_score": total_score,
        "max_score": max_score,
        "checks": results,
    }


def main():
    if len(sys.argv) < 2:
        print("用法: python3 checker.py <target容器名稱> [--loop 秒數]")
        sys.exit(1)

    target = sys.argv[1]
    loop_seconds = None
    if "--loop" in sys.argv:
        loop_seconds = int(sys.argv[sys.argv.index("--loop") + 1])

    out_path = f"leaderboard_{target}.json"

    while True:
        report = run_once(target)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        push_score_to_container(target, report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        print(f"\n總分: {report['total_score']}/{report['max_score']}  (寫入 {out_path}，已推送進容器)")

        if loop_seconds is None:
            break
        time.sleep(loop_seconds)


if __name__ == "__main__":
    main()
