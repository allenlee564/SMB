# Blue AI 一鍵啟動

Blue 的 `console.html` 需要 `/health` 與 `/api/generate` 兩個 AI API。這個版本把原本依賴 Windows 本機 `127.0.0.1:8765` 的 Blue AI 改成由 Docker Compose 一起啟動：

- `blue-ai`：Ollama + Blue AI 相容 API
- 模型：`qwen2.5:3b`
- 模型資料：`blue_ai_ollama` volume，第一次下載後不必每次重抓
- Windows `127.0.0.1:8765` 仍保留作健康檢查/除錯
- Blue Console 改走同源 `/ai/*`，由 `blue-terminal` Nginx 代理到 `blue-ai:8765`，避免瀏覽器跨 Port/CORS 問題
- AI 第一次尚未完成模型下載時，Console 會每 5 秒自動重試，不需要手動一直重新整理

## 啟動

在 `Metis\Blue`：

```cmd
docker compose down
docker compose up -d --build
```

第一次啟動需要下載 `qwen2.5:3b`，時間可能比較久。

查看狀態：

```cmd
docker compose ps
```

確認 `blue-ai-01` 變成 `Up (healthy)`。

查看 AI log：

```cmd
docker compose logs -f blue-ai
```

測試 Windows 8765：

```cmd
curl http://127.0.0.1:8765/health
```

成功時應看到類似：

```json
{"status":"ok","model":{"name":"qwen2.5:3b","loaded":true}}
```

然後開：

```text
http://localhost:17681/blue/landing.html
```

選 Easy 或 Normal 後，AI 應會變成 `● AI Ready`。

## 注意

`hard` 模式原本設計就是 `AI Disabled`，不會開放 AI，這是題目設定，不是故障。
