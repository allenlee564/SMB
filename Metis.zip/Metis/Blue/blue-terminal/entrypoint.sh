#!/bin/bash
set -e

TARGET_CONTAINER="${TARGET_CONTAINER:-target-box}"
TARGET_USER="${TARGET_USER:-root}"
DIFFICULTY="${DIFFICULTY:-normal}"

# 僅接受正式支援的難度值（照 PR #17 feat/blue-ai-integration 的邏輯搬過來）
case "$DIFFICULTY" in
    easy|normal|hard)
        ;;
    *)
        echo "WARN: Invalid DIFFICULTY='$DIFFICULTY', fallback to normal"
        DIFFICULTY="normal"
        ;;
esac

# 提供給瀏覽器讀取目前 Lab 難度（console.html 開頭會 fetch 這支）。
# 不包含 Checker、Score 或 Challenge 狀態——那些是 checker.py 的職責，跟這支無關。
mkdir -p /var/www/html/blue
cat > /var/www/html/blue/runtime.json <<EOF_RUNTIME
{
  "difficulty": "$DIFFICULTY"
}
EOF_RUNTIME

echo "Blue Terminal difficulty: $DIFFICULTY"

# 啟動 nginx（背景，daemon模式），前面包一層 /cli/ 乾淨路徑
nginx

# ttyd 當前景主行程，從外部 docker exec 進 target-box
exec ttyd -W -p 7681 docker exec -it -u "$TARGET_USER" "$TARGET_CONTAINER" bash
