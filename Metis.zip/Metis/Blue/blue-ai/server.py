#!/usr/bin/env python3
import json
import os
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
DEFAULT_MODEL = os.environ.get("MODEL", "qwen2.5:3b")


def ollama_request(path, method="GET", payload=None, timeout=15):
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(
        OLLAMA_URL + path, data=data, headers=headers, method=method
    )
    return urllib.request.urlopen(req, timeout=timeout)


def model_available(model):
    try:
        with ollama_request("/api/tags", timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        for item in data.get("models", []):
            name = item.get("name", "")
            if name == model or name.split(":", 1)[0] == model.split(":", 1)[0]:
                return True
    except Exception:
        pass
    return False


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        print("[blue-ai] " + (fmt % args), flush=True)

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if self.path != "/health":
            self.send_json(404, {"error": "not found"})
            return

        available = model_available(DEFAULT_MODEL)
        self.send_json(
            200 if available else 503,
            {
                "status": "ok" if available else "degraded",
                "model": {"name": DEFAULT_MODEL, "loaded": available},
            },
        )

    def do_POST(self):
        if self.path != "/api/generate":
            self.send_json(404, {"error": "not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length) or b"{}")
        except Exception as exc:
            self.send_json(400, {"error": f"invalid JSON: {exc}"})
            return

        model = payload.get("model") or DEFAULT_MODEL
        # 只允許目前 Blue 預期的本地模型，避免把這個 endpoint 變成任意 Ollama proxy。
        if model != DEFAULT_MODEL:
            model = DEFAULT_MODEL

        ollama_payload = {
            "model": model,
            "prompt": payload.get("prompt", ""),
            "stream": True,
        }
        for key in ("system", "options", "keep_alive"):
            if key in payload:
                ollama_payload[key] = payload[key]

        try:
            upstream = ollama_request(
                "/api/generate", method="POST", payload=ollama_payload, timeout=3600
            )
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.end_headers()

            while True:
                chunk = upstream.readline()
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
            upstream.close()
        except urllib.error.HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8", errors="replace")
            except Exception:
                detail = str(exc)
            self.send_json(502, {"error": f"Ollama HTTP {exc.code}: {detail}"})
        except Exception as exc:
            try:
                self.send_json(502, {"error": f"Ollama unavailable: {exc}"})
            except Exception:
                pass


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8765"))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"[blue-ai] listening on 0.0.0.0:{port}, model={DEFAULT_MODEL}", flush=True)
    server.serve_forever()
