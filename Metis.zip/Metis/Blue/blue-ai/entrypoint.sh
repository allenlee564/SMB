#!/bin/sh
set -eu

MODEL="${MODEL:-qwen2.5:3b}"

# Ollama 在容器內監聽，AI API 再透過 8765 對 Blue Terminal 提供相容介面。
OLLAMA_HOST="0.0.0.0:11434" OLLAMA_ORIGINS="*" nohup ollama serve >/tmp/ollama.log 2>&1 &

printf '%s\n' "Waiting for Ollama service to boot..."
until curl -fsS http://127.0.0.1:11434/ >/dev/null 2>&1; do
    sleep 2
done

printf 'Checking / pulling %s...\n' "$MODEL"
ollama pull "$MODEL"

exec env MODEL="$MODEL" python3 /app/server.py
