# THOTH 紅藍隊公版樣板

給紅隊、藍隊使用的統一視覺骨架：終端機/Cyberpunk 風格，紅隊配色偏攻擊感、藍隊配色偏防禦未來感，兩隊共用同一套排版、動畫與互動邏輯，只有配色與內文不同。純手寫 HTML/CSS/JS，**零外部依賴**（沒有 CDN 字型、沒有框架、不需要建置工具），跟這個 repo 現有的其他頁面（`Red/html/*.html`）技術水準一致。

## 目錄結構

```
Portal/
├── README.md                      本文件
├── landing-template.html          首頁（簡易說明 + 選擇滲透路徑）
├── console-template.html          主控台（難度選擇後跳轉到的操作頁）
└── shared/theme/
    ├── layout.css                 版面結構（flex/grid、間距、響應式斷點），不含顏色
    ├── theme.css                  配色、字體、裝飾特效、所有動畫
    └── thoth-interactions.js      背景動態效果、標題互動、頁面轉場、時鐘
```

**`shared/theme/` 是公用資源，紅藍隊都不要改**——這三個檔案定義了雙方共用的視覺語言（配色變數怎麼隨隊伍切換、版面怎麼排、互動怎麼做）。要調整視覺（例如配色、動畫節奏），改這裡；改完兩隊會同時受影響，動手前請先確認不會破壞另一隊的畫面。

`landing-template.html`、`console-template.html` 是**可以複製、可以改內容**的樣板：紅隊複製一份改成紅隊的版本，藍隊複製一份改成藍隊的版本，內文各自填寫，版面結構與 CSS class 請維持不動（一動就會跟 `shared/theme/*` 對不上，樣式會跑掉）。

## 紅隊／藍隊怎麼套用

1. 複製 `landing-template.html`、`console-template.html`（連同 `shared/theme/` 一起複製到你要用的位置，或維持指到同一份 `shared/theme/` 也可以，只要相對路徑 `shared/theme/...` 還能找到就行）。
2. 兩個檔案的 `<html>` 標籤都要改隊伍：
   ```html
   <!-- 紅隊 -->
   <html lang="zh-TW" data-team="red">
   <body class="fx-glitch">

   <!-- 藍隊 -->
   <html lang="zh-TW" data-team="blue">
   <body class="fx-hud">
   ```
   `data-team` 控制配色（`theme.css` 裡 `:root[data-team="blue"]` 那段），`fx-glitch`/`fx-hud` 是預留給未來隊伍專屬特效用的掛鉤（目前兩者本身沒有額外效果，配色已經靠 `data-team` 切換掉了）。
3. 填內容：兩份檔案裡用 `<!-- [INJECT: 名稱] -->` … `<!-- [/INJECT: 名稱] --> ` 註解框起來的地方，把裡面的文字/清單換成自己隊伍的內容，**結構（`<p>`、`<div class="chain">`、`<details>` 等）盡量照抄，只換文字**：
   - `landing-template.html`：`BOOT_TEXT`（開場 boot log 幾行字 + 副標打字機文字，`#bootLog` 的 `data-lines` 屬性用 `|` 分隔每一行、`#typewrite` 的 `data-text` 屬性放副標，直接改屬性值就好，**不用去動 `shared/theme/thoth-interactions.js`**）、`TEAM_INTRO`（簡易說明段落）、`DIFFICULTY_OPTIONS`（難度按鈕，文案可換但 `onclick="thothNavigate(...)"` 這行請保留，這是導到主控台的機制——**細節見下一點**）。
   - `console-template.html`：`SIDEBAR_RESOURCES`（左側戰術資源庫手風琴內容）、`TERMINAL_IFRAME`（中間 Kali VM 終端機，之後接 ttyd/iframe 時換掉裡面的預留文字）、`AI_CHAT_PROMPT`（右側 AI 助手開場白，之後接 OpenRouter 時這裡會變成即時對話）、`TASK_DESCRIPTION`（底部題目說明）。
4. **難度跟主控台頁的對應關係**：`landing-template.html` 的三個難度按鈕目前都指到同一份 `console-template.html`，這只是範例。因為題目內容通常會跟難度綁在一起（不同的終端機目標、AI 助手提示、題目說明），建議照 `Red/html/` 現有慣例，**每個難度各自複製一份 `console-template.html`**（例如 `console-easy.html`、`console-normal.html`、`console-hard.html`），把三顆按鈕的網址各自換成對應檔名即可，不需要另外寫 JS 做動態切換。
5. `console-template.html` 故意沒有背景動態效果（沒有 `<div class="atmosphere">`），因為那頁是實際操作終端機的工作畫面，背景保持靜止比較不分心；花俏效果（背景粒子、游標互動、漣漪）都只在 `landing-template.html`。如果你的隊伍不需要這個區分，可以自行決定要不要把 `<div class="atmosphere">...</div>` + `<canvas id="bg-canvas">` 那幾行也搬到 `console-template.html`（`thoth-interactions.js` 已經對 `#bg-canvas` 是否存在做了防呆，不會因為少了這個元素而報錯）。
6. `console-template.html` 最上面有一個「作戰主控台」的小標籤（`.eyebrow`），這是頁面定位用的，不用刪，也不用改（除非你想換文字）。
7. 版面裡零星出現的 `[LOC_0x7F]`、`[LOC_0x2C]` 這類方括號標籤是純裝飾（模擬座標/位置代碼的 FUI 風格），**不需要填寫或理解意義**，不改也沒關係。

## 換隊伍檢查清單

`[INJECT: ...]` 註解框住的地方涵蓋大部分內容，但有幾個地方是**單獨一行、沒有被框起來**，容易漏改（實測跑過一次紅→藍的改版流程才抓出來，已經在對應位置加了 HTML 註解提醒，這裡再列一次方便勾）：

- [ ] `landing-template.html` 的 `<html data-team="red">` → `"blue"`、`<body class="fx-glitch">` → `"fx-hud"`
- [ ] `console-template.html` 的 `<html data-team="red">` → `"blue"`、`<body class="fx-glitch">` → `"fx-hud"`
- [ ] `landing-template.html` 的 `#teamStatus`（topbar，「紅隊 · 進攻模式」）
- [ ] `console-template.html` 的 `#teamStatus`（topbar，同上，兩個檔案各自獨立要改）
- [ ] `landing-template.html` 的 `#teamLabel`（hero 副標裡的「紅隊」兩個字，在 `BOOT_TEXT` 區塊內）
- [ ] `landing-template.html` 的 `#footTeam`（footer 的「MODE: RED TEAM // OFFENSIVE OPERATIONS」）
- [ ] `TEAM_INTRO`、`DIFFICULTY_OPTIONS`、`SIDEBAR_RESOURCES`、`TERMINAL_IFRAME`、`AI_CHAT_PROMPT`、`TASK_DESCRIPTION` 這幾個 `[INJECT]` 區塊

改完之後直接雙擊打開兩個檔案，確認畫面上已經看不到任何「紅隊」/「RED TEAM」字樣（除非你就是紅隊，那反過來確認沒有「藍隊」殘留）。

## 沒有隊伍切換按鈕

這份公版**沒有**「紅隊/藍隊」互動切換鈕——每一份部署出去的檔案本來就是單一隊伍（`data-team` 在複製當下就寫死了），加一顆可以切換配色的按鈕不只沒必要，還有風險：畫面上其他文字（隊伍狀態、簡易說明標題等）如果做成「按下去就換一批寫死的泛用字」，反而會蓋掉你自己填進去的內容。如果你在開發階段想快速比較紅/藍兩種配色，直接把 `<html data-team="red">` 手動改成 `"blue"` 存檔重新整理即可，不需要也不建議做成即時切換 UI。

## 畫面渲染怎麼取用／預覽

**最簡單的方式：直接用瀏覽器打開檔案（`file://`）。**

因為 `<link>`/`<script src>` 用的是**相對路徑**（`shared/theme/layout.css` 這種寫法），只要 `landing-template.html`、`console-template.html` 跟 `shared/` 資料夾維持原本的相對位置關係，直接在檔案總管裡雙擊 `.html` 檔用瀏覽器打開就會正確載入樣式跟互動——不需要架設本機伺服器，也不用裝任何東西。這跟 `fetch`/AJAX 在 `file://` 下會被瀏覽器擋掉不一樣：`<link>`/`<script>` 引用本機相對路徑檔案，在 `file://` 底下一樣正常運作。

想確認效果的人只要：
1. 把整個 `Portal/`（或至少 `landing-template.html`/`console-template.html` + `shared/`）複製到自己電腦。
2. 雙擊 `landing-template.html`。
3. 點難度按鈕會跳轉到 `console-template.html`，右上角「返回首頁」再跳回去——這就是實際 render 出來、可以互動的畫面，跟畫圖軟體的靜態預覽不一樣，滑鼠移動/點擊都是真的會動的。

## 之後要接進 Docker/nginx 的話

目前 `Red/html/` 是直接被 `Red/Dockerfile` 的 `COPY html/ /var/www/html/` 包進紅隊容器對外提供，`Blue/blue-terminal/` 目前**還沒有**承載網頁的機制（`blue-terminal` 的 nginx 根路徑目前只回一行純文字，藍隊要能真的把這個公版掛出來，需要另外幫 `Blue/blue-terminal/Dockerfile` 加 `COPY html/ /var/www/html/`、幫 `Blue/blue-terminal/nginx.conf` 加 `root`/`location` 設定，這部分留給下一輪整合）。

因為 Red 跟 Blue 是各自獨立的 Docker build context，`shared/theme/` 沒辦法直接被兩邊的 Dockerfile 同時 `COPY` 到——build context 之外的檔案 Docker 本來就拿不到。之後真的要接容器時，建議：`Portal/shared/theme/` 當唯一維護來源，另外寫一支同步腳本，build 前把它複製一份進 `Red/html/assets/theme/` 跟未來的 `Blue/blue-terminal/html/assets/theme/`，兩邊各自的 Dockerfile 再照平常方式 `COPY html/ ...`。這個腳本這輪還沒寫，只是先把方向記在這裡。
