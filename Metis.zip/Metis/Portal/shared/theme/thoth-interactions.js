/* ============================================================
   THOTH shared theme — thoth-interactions.js
   Shared behaviour for landing-template.html AND console-template.html.
   Because the same script serves two different page structures, every
   DOM lookup is guarded (an element may legitimately not exist on one
   of the two pages). Pair with layout.css + theme.css.
   ============================================================ */

(function () {
  'use strict';

  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---- background canvas: drifting particle dust (red) / clean cyber grid
  // (blue). Cursor sways existing dust sideways (never spawns more of it);
  // a click sends an outward impulse plus a visible expanding ring. Fully
  // absent on pages with no #bg-canvas (e.g. a page that opts out). ----
  (function () {
    var canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = 0, h = 0;
    // data-team is read once here and never changes at runtime — each
    // deployed page is single-team, set once in the HTML (see README.md).
    var team = document.documentElement.getAttribute('data-team') || 'red';
    var rafId = null;
    var redParticles = [];
    var blueDots = [];
    var ripples = [];
    var mouse = { x: -9999, y: -9999 };

    function makeRedParticle(fromBottom) {
      return {
        x: Math.random() * w,
        y: fromBottom ? h + Math.random() * 30 : Math.random() * h,
        r: 0.8 + Math.random() * 1.6,
        vy: 0.12 + Math.random() * 0.35,
        vx: 0,
        phase: Math.random() * Math.PI * 2,
        freq: 0.6 + Math.random() * 0.8,
        amp: 6 + Math.random() * 14,
        hot: Math.random() > 0.6
      };
    }
    function seedRed() {
      var count = Math.min(90, Math.round((w * h) / 16000));
      redParticles = [];
      for (var i = 0; i < count; i++) redParticles.push(makeRedParticle(false));
    }
    function seedBlue() {
      var step = 46;
      blueDots = [];
      for (var x = step; x < w; x += step) {
        for (var y = step; y < h; y += step) {
          blueDots.push({ x: x, y: y, phase: Math.random() * Math.PI * 2 });
        }
      }
    }
    function spawnRipple(x, y) {
      ripples.push({ x: x, y: y, r: 0, alpha: 0.55 });
      if (team !== 'red') return; // blue's grid dots are fixed-position, nothing to push
      var pushR = 150, pushR2 = pushR * pushR;
      for (var i = 0; i < redParticles.length; i++) {
        var p = redParticles[i];
        var dx = p.x - x, dy = p.y - y;
        var d2 = dx * dx + dy * dy;
        if (d2 < pushR2 && d2 > 1) {
          var d = Math.sqrt(d2);
          var force = (1 - d / pushR) * 2.4;
          p.vx += (dx / d) * force;
        }
      }
    }
    function resize() {
      w = window.innerWidth; h = window.innerHeight;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seedRed();
      seedBlue();
    }
    function smoothstep(u) { return u * u * (3 - 2 * u); }
    function drawRipples(colorTriplet) {
      for (var j = ripples.length - 1; j >= 0; j--) {
        var rp = ripples[j];
        rp.r += 3.2;
        rp.alpha -= 0.016;
        if (rp.alpha <= 0) { ripples.splice(j, 1); continue; }
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(' + colorTriplet + ',' + rp.alpha + ')';
        ctx.lineWidth = 1.5;
        ctx.arc(rp.x, rp.y, rp.r, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
    function drawRed(t) {
      ctx.clearRect(0, 0, w, h);
      var repelR = 90, repelR2 = repelR * repelR;
      for (var i = 0; i < redParticles.length; i++) {
        var p = redParticles[i];
        var dx = p.x - mouse.x, dy = p.y - mouse.y;
        var d2 = dx * dx + dy * dy;
        if (d2 < repelR2 && d2 > 1) {
          var d = Math.sqrt(d2);
          var force = (1 - d / repelR) * 0.5;
          p.vx += (dx / d) * force;
        }
        p.vx *= 0.92;
        p.y -= p.vy;
        p.x += p.vx;
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;
        if (p.y < -10) { redParticles[i] = makeRedParticle(true); continue; }
        var jx = p.x + Math.sin(t * 0.001 * p.freq + p.phase) * (p.amp * 0.02);
        var color = p.hot ? '255,154,61' : '255,51,87';
        ctx.beginPath();
        ctx.fillStyle = 'rgba(' + color + ',0.65)';
        ctx.shadowColor = 'rgba(' + color + ',0.9)';
        ctx.shadowBlur = 6;
        ctx.arc(jx, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.shadowBlur = 0;
      drawRipples('255,90,90');
    }
    function drawBlue(t) {
      ctx.clearRect(0, 0, w, h);
      var step = 46;
      ctx.strokeStyle = 'rgba(47,215,255,0.045)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (var x = 0; x < w; x += step) { ctx.moveTo(x, 0); ctx.lineTo(x, h); }
      for (var y = 0; y < h; y += step) { ctx.moveTo(0, y); ctx.lineTo(w, y); }
      ctx.stroke();
      var repelR = 160, repelR2 = repelR * repelR;
      for (var i = 0; i < blueDots.length; i++) {
        var d = blueDots[i];
        var tw = 0.32 + Math.sin(t * 0.0006 + d.phase) * 0.18;
        var dx = d.x - mouse.x, dy = d.y - mouse.y;
        var d2 = dx * dx + dy * dy;
        var near = d2 < repelR2 ? Math.max(0, 1 - Math.sqrt(d2) / repelR) : 0;
        var boost = smoothstep(near);
        ctx.beginPath();
        ctx.fillStyle = 'rgba(47,215,255,' + Math.max(0, tw + boost * 0.55) + ')';
        ctx.arc(d.x, d.y, 1.1 + boost * 1.4, 0, Math.PI * 2);
        ctx.fill();
      }
      drawRipples('47,215,255');
    }
    function frame(t) {
      if (team === 'blue') drawBlue(t); else drawRed(t);
      rafId = requestAnimationFrame(frame);
    }
    function debounce(fn, ms) {
      var tm;
      return function () { clearTimeout(tm); tm = setTimeout(fn, ms); };
    }
    window.addEventListener('resize', debounce(resize, 150));
    window.addEventListener('mousemove', function (e) { mouse.x = e.clientX; mouse.y = e.clientY; });
    window.addEventListener('mouseleave', function () { mouse.x = -9999; mouse.y = -9999; });
    window.addEventListener('click', function (e) {
      spawnRipple(e.clientX, e.clientY);
    });
    resize();
    if (reduceMotion) {
      team === 'blue' ? drawBlue(0) : drawRed(0);
    } else {
      rafId = requestAnimationFrame(frame);
    }
  })();

  // ---- title glow (landing page only): cursor position feeds the
  // radial-gradient's center defined on .glitch-title in theme.css.
  // No canvas, no particles, no idle motion. ----
  (function () {
    if (reduceMotion) return;
    var wrap = document.querySelector('.glitch-wrap');
    var ttl = document.getElementById('titleText');
    if (!wrap || !ttl) return; // not present on console-template.html
    wrap.addEventListener('mousemove', function (e) {
      var r = ttl.getBoundingClientRect();
      ttl.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      ttl.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
    wrap.addEventListener('mouseleave', function () {
      ttl.style.setProperty('--mx', '-9999px');
      ttl.style.setProperty('--my', '-9999px');
    });
  })();

  // ---- page transition: landing-template.html <-> console-template.html.
  // These are two separate files, so "navigating" is a real page load;
  // this just adds a brief boot-style flash via #loadingOverlay first. ----
  window.thothNavigate = function (url, label) {
    var overlay = document.getElementById('loadingOverlay');
    var loadingText = document.getElementById('loadingText');
    var duration = reduceMotion ? 0 : 900;
    if (overlay && !reduceMotion) {
      overlay.classList.add('active');
      if (loadingText && label) loadingText.textContent = label;
    }
    setTimeout(function () { window.location.href = url; }, duration);
  };

  // Note: there is deliberately no runtime team switcher here. Each deployed
  // copy of a page is single-team — data-team is set once in the HTML when
  // a team copies the template (see README.md) — so the background canvas
  // above just reads it once at load and that's it.

  // ---- boot log (landing page only) ----
  // Lines come from the element's own data-lines attribute (pipe-separated)
  // so each team can edit the wording directly in their copy of the HTML
  // without touching this shared file. Falls back to a generic default.
  var bootEl = document.getElementById('bootLog');
  if (bootEl) {
    var bootLines = bootEl.dataset.lines
      ? bootEl.dataset.lines.split('|')
      : [
          '> establishing secure channel to thoth-range...',
          '> loading modules...',
          '> syncing scenario data...',
          '> ready.'
        ];
    if (reduceMotion) {
      bootEl.innerHTML = bootLines.map(function (l, i) {
        return '<span' + (i === bootLines.length - 1 ? ' class="ok"' : '') + '>' + l + '</span>';
      }).join('');
    } else {
      var li = 0;
      (function nextLine() {
        if (li >= bootLines.length) return;
        var span = document.createElement('span');
        if (li === bootLines.length - 1) span.className = 'ok';
        bootEl.appendChild(span);
        var text = bootLines[li];
        var ci = 0;
        (function typeChar() {
          if (ci <= text.length) {
            span.textContent = text.slice(0, ci);
            ci++;
            setTimeout(typeChar, 12);
          } else {
            li++;
            setTimeout(nextLine, 120);
          }
        })();
      })();
    }
  }

  // ---- typewriter subtitle (landing page only) ----
  // Text comes from the element's own data-text attribute for the same
  // reason as the boot log — editable per team without touching this file.
  var twEl = document.getElementById('typewrite');
  if (twEl) {
    var subtitle = twEl.dataset.text || '';
    if (reduceMotion) {
      twEl.textContent = subtitle;
    } else {
      var i = 0;
      var typeSub = function () {
        twEl.innerHTML = subtitle.slice(0, i) + '<span class="cur">▌</span>';
        if (i < subtitle.length) { i++; setTimeout(typeSub, 26); }
      };
      setTimeout(typeSub, 900);
    }
  }

  // ---- session clock (topbar, both pages) ----
  var clockEl = document.getElementById('clock');
  if (clockEl) {
    (function tick() {
      var d = new Date();
      var p = function (n) { return String(n).padStart(2, '0'); };
      clockEl.textContent = p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
      setTimeout(tick, 1000);
    })();
  }
})();
