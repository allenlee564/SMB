#!/bin/bash

# 1. 啟動 Nginx
nginx

# 2. 啟動 ttyd (開啟可寫入模式 -W)
nohup ttyd -W -p 7681 -w /root bash > /dev/null 2>&1 &

# 3. 帶入 0.0.0.0 與跨域變數啟動 Ollama
OLLAMA_HOST=0.0.0.0:11434 OLLAMA_ORIGINS="*" nohup ollama serve > /dev/null 2>&1 &

# 4. 等待 Ollama 服務啟動完畢後自動拉取 qwen2.5:3b 模型
echo "Waiting for Ollama service to boot..."
until curl -s http://127.0.0.1:11434/ > /dev/null; do
    sleep 2
done

echo "Checking / Pulling qwen2.5:3b model..."
ollama pull qwen2.5:3b

# 5. 維持容器前景運作
tail -f /dev/null
