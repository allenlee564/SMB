# 資安攻防演練環境架設文件（Cyber Range Build Spec）

> 給後續 agent 的架設規格。照本文件執行即可重現整個環境。
> 定址採**可擴充規則**（見 §3），支援 7 台以上 VM，新增 VM 只需套公式，勿自行亂編網段。

---

## 1. 目標與設計原則

- 多台 VM（host 為 Windows + VirtualBox），每台以 Docker 容器跑 6 台 Kali 攻擊機（可擴充）。
- **每一台 Kali 各自獨立網段**，彼此在 L2 與 L3 都完全隔離（不同 Docker network = 不同廣播網域）。
- **不做 NAT/masquerade**：VM 當純路由器，WebServer 與防火牆看到的是容器的**原始 IP**。
- 藍隊可在防火牆上依容器真實 IP 精準封鎖單一攻擊機，或整段封鎖一台 VM 的全部攻擊機，封鎖粒度由藍隊決策。

### 已知取捨（務必知悉，非設定錯誤）

因每台 Kali 隔離在各自 `/29`，唯一鄰居是自己的 gateway，**攻擊封包必須經 VM 繞送才出得去**。因此：

- **L2 攻擊對 WebServer 一律無效**：ARP spoofing、LLMNR/NBT-NS poisoning、Responder 到不了目標廣播網域。
- 若演練腳本含上述 L2 手法，「每台隔離」與「L2 攻擊」互斥，需回報決策者二選一。本文件採「完全隔離」版本。

---

## 2. 拓撲

```
                        [ Router ]
                            |
                        [ Switch ]
       _____________________|_____________________________
      |        |        |        |   ...   |        |      |
    VM (.10) VM (.11) VM (.12)  ...      VM (.16)  [ Firewall ]
      |        |        |                  |            |
   6x Kali  6x Kali  6x Kali    ...     6x Kali    ____|____
  172.31.  172.31.  172.31.             172.31.   |         |
   10.x     11.x     12.x                16.x   Dashboard WebServer
```

- 圖示 7 台 VM（`10.167.223.10` ~ `.16`），數量可再擴充。
- Dashboard、WebServer 位於防火牆同一側；兩者間流量不經防火牆（Watchdog 若送資料給 Dashboard，該路徑不被記錄，屬預期）。

---

## 3. 定址規則（可擴充，核心）

### 3.1 母網段分配公式

```
VM host IP:  10.167.223.<X>
母網段:      172.31.<X>.0/24        ← 第三碼 = VM host IP 最後一碼
```

VM host IP 取連續區塊，`<X>` 即當作容器母網段第三碼，天然不重疊、易對照。

| VM | host IP | 容器母網段 | Docker project 名 |
|----|---------|-----------|-------------------|
| VM10 | 10.167.223.10 | 172.31.10.0/24 | vm10 |
| VM11 | 10.167.223.11 | 172.31.11.0/24 | vm11 |
| VM12 | 10.167.223.12 | 172.31.12.0/24 | vm12 |
| VM13 | 10.167.223.13 | 172.31.13.0/24 | vm13 |
| VM14 | 10.167.223.14 | 172.31.14.0/24 | vm14 |
| VM15 | 10.167.223.15 | 172.31.15.0/24 | vm15 |
| VM16 | 10.167.223.16 | 172.31.16.0/24 | vm16 |
| …    | 10.167.223.\<X\> | 172.31.\<X\>.0/24 | vm\<X\> |

> `172.31.0.0/16` 空間充足，最多 256 個 `/24`（即 256 台 VM），遠超需求。

### 3.2 每台 VM 內部的 6 個 /29（所有 VM 結構相同，僅第三碼 = `<X>`）

以 `<X>` 代表該 VM 的母網段第三碼：

| 容器 | 子網段 (/29) | Gateway | 容器 IP |
|------|--------------|---------|---------|
| kali1 | 172.31.\<X\>.0/29  | 172.31.\<X\>.1  | 172.31.\<X\>.2  |
| kali2 | 172.31.\<X\>.8/29  | 172.31.\<X\>.9  | 172.31.\<X\>.10 |
| kali3 | 172.31.\<X\>.16/29 | 172.31.\<X\>.17 | 172.31.\<X\>.18 |
| kali4 | 172.31.\<X\>.24/29 | 172.31.\<X\>.25 | 172.31.\<X\>.26 |
| kali5 | 172.31.\<X\>.32/29 | 172.31.\<X\>.33 | 172.31.\<X\>.34 |
| kali6 | 172.31.\<X\>.40/29 | 172.31.\<X\>.41 | 172.31.\<X\>.42 |

範例（`<X>=11`）：kali1 = `172.31.11.2`、kali5 = `172.31.11.34`。
`.0/29` ~ `.40/29` 用掉 `.0–.47`，`.48` 起可續切，每台 VM 最多 32 台 Kali。

---

## 4. 防火牆（靶機側閘道）

### 4.1 靜態路由（環境運作前提，每台 VM 一條）

規則：`S  172.31.<X>.0/24  via  10.167.223.<X>`

```
S  172.31.10.0/24  via  10.167.223.10
S  172.31.11.0/24  via  10.167.223.11
S  172.31.12.0/24  via  10.167.223.12
S  172.31.13.0/24  via  10.167.223.13
S  172.31.14.0/24  via  10.167.223.14
S  172.31.15.0/24  via  10.167.223.15
S  172.31.16.0/24  via  10.167.223.16
```

Dashboard、WebServer 的預設閘道指向防火牆即可，本身不加路由。**每新增一台 VM，補一條對應路由。**

> 進階：若所有 VM host IP 落在同一連續區塊且母網段規則一致，可考慮以彙總路由簡化，但混合廠牌/介面時容易誤判回程介面，建議維持一台一條、明確可讀。

### 4.2 RPF 檢查（FortiGate 常見卡點）

FortiGate 預設 strict RPF：封包從 `10.167.223.x` 介面進、來源為 `172.31.x`，須路由對得起來才放行。**務必先加好 §4.1 路由再測連線**，否則封包被靜默丟棄。

除錯時暫時放寬：

```
config system settings
    set strict-src-check disable
end
```

---

## 5. VM 端架設（每台 VM 重複，靠 VMID 區分）

### 5.1 前置

- OS：Linux VM（Debian/Ubuntu 建議），已裝 Docker Engine + docker compose plugin。
- VirtualBox 網卡：**橋接介面卡**，橋到實體網卡（非 Wi-Fi）。
- VM host 靜態 IP `10.167.223.<X>/24`，閘道指向 Switch/Router 側。
- 確認轉發已開（Docker 安裝後預設開）：`sysctl net.ipv4.ip_forward` 應為 `1`。

### 5.2 Kali image（先建好共用 image，勿每台重裝；每台 VM 各建一次或用 registry 分發）

```bash
docker run -dit --name kali-base kalilinux/kali-rolling
docker exec kali-base bash -c "apt update && apt install -y kali-linux-headless"
docker commit kali-base kali-lab
docker rm -f kali-base
```

> 建議：建一次後 `docker save kali-lab | ...` 或推到內網 registry，各 VM `docker load/pull`，確保 image 一致。

### 5.3 參數化 compose（**所有 VM 共用同一份**）

存成 `kali-compose.yml`。網段以 `${VMID}` 帶入，同一份檔案套用到任何 VM。

```yaml
x-kali: &kali
  image: kali-lab
  cap_add: [NET_ADMIN, NET_RAW]   # 勿用 --privileged
  stdin_open: true
  tty: true
  restart: unless-stopped

x-net-opts: &nomasq
  driver: bridge
  driver_opts:
    com.docker.network.bridge.enable_ip_masquerade: "false"

networks:
  k1: {<<: *nomasq, ipam: {config: [{subnet: 172.31.${VMID}.0/29,  gateway: 172.31.${VMID}.1}]}}
  k2: {<<: *nomasq, ipam: {config: [{subnet: 172.31.${VMID}.8/29,  gateway: 172.31.${VMID}.9}]}}
  k3: {<<: *nomasq, ipam: {config: [{subnet: 172.31.${VMID}.16/29, gateway: 172.31.${VMID}.17}]}}
  k4: {<<: *nomasq, ipam: {config: [{subnet: 172.31.${VMID}.24/29, gateway: 172.31.${VMID}.25}]}}
  k5: {<<: *nomasq, ipam: {config: [{subnet: 172.31.${VMID}.32/29, gateway: 172.31.${VMID}.33}]}}
  k6: {<<: *nomasq, ipam: {config: [{subnet: 172.31.${VMID}.40/29, gateway: 172.31.${VMID}.41}]}}

services:
  kali1: {<<: *kali, container_name: vm${VMID}_kali1, networks: {k1: {ipv4_address: 172.31.${VMID}.2}}}
  kali2: {<<: *kali, container_name: vm${VMID}_kali2, networks: {k2: {ipv4_address: 172.31.${VMID}.10}}}
  kali3: {<<: *kali, container_name: vm${VMID}_kali3, networks: {k3: {ipv4_address: 172.31.${VMID}.18}}}
  kali4: {<<: *kali, container_name: vm${VMID}_kali4, networks: {k4: {ipv4_address: 172.31.${VMID}.26}}}
  kali5: {<<: *kali, container_name: vm${VMID}_kali5, networks: {k5: {ipv4_address: 172.31.${VMID}.34}}}
  kali6: {<<: *kali, container_name: vm${VMID}_kali6, networks: {k6: {ipv4_address: 172.31.${VMID}.42}}}
```

### 5.4 各 VM 啟動（`VMID` = 該 VM host IP 最後一碼）

在 VM11 上：

```bash
VMID=11 docker compose -p vm11 -f kali-compose.yml up -d
```

在 VM16 上：

```bash
VMID=16 docker compose -p vm16 -f kali-compose.yml up -d
```

> `-p vm<X>` 讓 project 名唯一。也可改用 `.env`：於 VM 建 `echo "VMID=11" > .env` 後直接 `docker compose -p vm11 -f kali-compose.yml up -d`。
> 若後續 agent 偏好靜態展開的檔案，可先 `VMID=11 docker compose -f kali-compose.yml config > vm11-compose.yml` 產生固定版本再部署。

---

## 6. 轉發規則與持久化（每台 VM）

### 6.1 從外部連入容器（藍隊反掃、WebServer 主動回連）

純出站攻擊靠 conntrack 處理回程，**不需加規則**。若需外部主動連入容器，才加（`<X>` = VMID）：

```bash
iptables -I DOCKER-USER -d 172.31.<X>.0/24 -j ACCEPT
```

**切勿使用 `--iptables=false`**，會破壞 Docker 整組網路功能。

### 6.2 持久化

```bash
apt install -y iptables-persistent
netfilter-persistent save
```

compose 服務已設 `restart: unless-stopped`，VM 重開後容器自動起。

---

## 7. 驗證清單（每台 VM）

容器內：

```bash
docker exec -it vm<X>_kali1 bash
ip a                         # 應只有一個介面 + 自己的 /29
ip route                     # default via 該網段 gateway
ping -c1 <WebServer_IP>      # 應通（經 VM 繞送 + 防火牆放行後）
```

WebServer / 防火牆確認來源 IP 為容器原始 IP（非 VM IP）：

```bash
tcpdump -ni any host 172.31.<X>.2
```

**隔離驗證（關鍵）**：同 VM 不同容器應互不可達：

```bash
docker exec vm<X>_kali1 ping -c1 172.31.<X>.10   # 預期 timeout
```

防火牆 log 應見各容器真實 IP，可據此精準封鎖。

---

## 8. Watchdog / 監控建議（如需）

容器流量對應 VM 上 `br-xxxx` 介面，一 network 對一台 Kali，證據天然分離。對照表：

```bash
docker network ls -q | xargs -n1 docker network inspect \
  -f '{{.Name}} br-{{slice .Id 0 12}} {{range .IPAM.Config}}{{.Subnet}}{{end}}'
```

側錄（out-of-band，容器碰不到）：

```bash
tcpdump -i br-<id> -w /captures/vm<X>_kali1.pcap
```

建議：網路層從 VM 抓、主機層由容器內 agent 單向推送；勿讓 Watchdog 成為容器可連入的跳板。

---

## 9. 新增一台 VM 的標準流程（Checklist）

1. 配 VM host IP `10.167.223.<X>`（`<X>` 為未使用的最後一碼），橋接、靜態 IP。
2. 裝 Docker，載入 `kali-lab` image。
3. 放入共用的 `kali-compose.yml`。
4. `VMID=<X> docker compose -p vm<X> -f kali-compose.yml up -d`。
5. 防火牆加一條路由：`S 172.31.<X>.0/24 via 10.167.223.<X>`。
6. （如需連入）VM 上 `iptables -I DOCKER-USER -d 172.31.<X>.0/24 -j ACCEPT` 並持久化。
7. 跑 §7 驗證。

> 單台 VM 要加 Kali（超過 6 台）：於 compose 補 `.48/29`、`.56/29`… 遞增，母 `/24` 內最多 32 台。
