# 協作規範
## 分支

從 `main` 開，命名 `<類型>/<組別>-<短描述>`：

```
feat/red-web-terminal
fix/blue-log-parser
docs/purple-threat-model
```

- 類型只有三種：`feat` / `fix` / `docs`。想不到用哪個就用 `feat`。
- 合併後刪掉分支（GitHub 會問，按下去就好）。

## PR

- **一個 PR 做一件事**。
- 標題寫「這個 PR 讓什麼變成可能」，不是「改了哪些檔案」。

## Commit 訊息

一行祈使句，說明「為什麼」而不是「改了什麼」，用中文即可：

- 好：`使用本地大模型避免資料傳輸到第三方`
- 壞：`update`、`fix bug`、`修改檔案`

## 筆記（Metis-notes/）

- **一個檔案一個負責人**。要動別人的檔案，先在群組講一聲。
- 開始寫之前先 `git pull`。
- 決策類內容寫成獨立檔案（`決策記錄 00X - 標題.md`），不要全部塞進同一個大檔。

## 絕對不要 commit

**刪掉也沒用，還留在歷史裡**：

- 任何憑證：`.env`、API key、SSH key、密碼、token
- 真實掃描結果、target 清單、校內或客戶系統的 IP／網域
- Docker volume 資料、build 產物、log
- 個人編輯器設定（`.obsidian/`、`.claude/` 已在 .gitignore）

不確定能不能 commit → 先問，不要先推。
